public class ShopItem {
    Weapon item;
    int numOfStock;

    public ShopItem(Weapon w,int stock){
        this.item = w;
        this.numOfStock = stock;
    }
}